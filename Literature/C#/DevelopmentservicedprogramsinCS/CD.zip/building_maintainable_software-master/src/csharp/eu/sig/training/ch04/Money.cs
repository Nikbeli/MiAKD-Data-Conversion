﻿namespace eu.sig.training.ch04
{
    public class Money
    {
        public bool GreaterThan(int limit)
        {
            return true;
        }
    }
}
