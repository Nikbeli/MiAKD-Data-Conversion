namespace eu.sig.training.ch03
{

    public enum Nationality
    {
        DUTCH,
        GERMAN,
        BELGIAN,
        FRENCH,
        ITALIAN,
        LUXEMBOURGER,
        UNCLASSIFIED
    }
}
