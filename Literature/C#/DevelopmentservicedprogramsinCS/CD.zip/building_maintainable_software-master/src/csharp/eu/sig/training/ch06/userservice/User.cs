namespace eu.sig.training.ch06.userservice
{

    public class User
    {
        public string Name { get; set; }

        public User()
        {
            Name = "user@example.com";
        }
    }

}
