﻿namespace eu.sig.training.ch07
{
    public interface ICloudStorage
    {
    }
}
