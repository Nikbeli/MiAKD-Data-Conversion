﻿namespace eu.sig.training.ch07
{
    public class AzureDatabaseServer : ICloudServer
    {
    }
}