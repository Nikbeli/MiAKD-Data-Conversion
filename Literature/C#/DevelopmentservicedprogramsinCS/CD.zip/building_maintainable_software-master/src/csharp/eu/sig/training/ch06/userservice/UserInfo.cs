namespace eu.sig.training.ch06.userservice
{

    public class UserInfo
    {
    }

}