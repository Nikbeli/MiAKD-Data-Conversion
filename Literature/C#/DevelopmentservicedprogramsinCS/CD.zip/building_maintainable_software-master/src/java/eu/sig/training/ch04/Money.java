package eu.sig.training.ch04;

public class Money {
    @SuppressWarnings("unused")
    public boolean greaterThan(int limit) {
        return true;
    }
}
