package eu.sig.training.ch07;

public class AzureComputeServer implements CloudServer {

}
