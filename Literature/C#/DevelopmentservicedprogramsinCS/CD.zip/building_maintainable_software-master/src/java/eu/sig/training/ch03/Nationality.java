package eu.sig.training.ch03;

public enum Nationality {
    DUTCH, GERMAN, BELGIAN, LUXEMBOURGER, FRENCH, ITALIAN, UNCLASSIFIED
}